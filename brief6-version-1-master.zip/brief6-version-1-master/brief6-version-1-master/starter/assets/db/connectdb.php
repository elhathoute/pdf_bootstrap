<?php 
$hostname ='localhost';
$dbname   ='tasks';
$usernmae  ='root';
$password  ='';

 $connexion = mysqli_connect($hostname,$usernmae,$password,$dbname);
 if(!$connexion){
    die('Connexion base donne failed :'.mysqli_connect_errno());
 }

?>