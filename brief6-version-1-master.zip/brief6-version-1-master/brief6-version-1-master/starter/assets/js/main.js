// //localStorage.clear()
// var todo = document.getElementById("TodoTask");
// var inProgress = document.getElementById("in-Progress ");
// var done = document.getElementById("done-task");
// var spanToDo = document.getElementById("to-do-tasks-count");
// var spanInProgress = document.getElementById("in-progress-tasks-count");
// var spanDone = document.getElementById("done-tasks-count");
// let addTask = document.getElementById("SaveTask");
// var form = document.querySelector("form");
// var tableOfTaskS = localStorage.getItem('tableOfTaskS') ? JSON.parse(localStorage.getItem('tableOfTaskS')) : [];
// affichage();
// form.addEventListener("submit", () => {

//     var TabTask = {
//         titre: form.titre.value,
//         description: form.description.value,
//         date: form.date.value,
//         priority: form.priority.value,
//         status: form.status.value,
//         type: document.querySelector('input[name="radio"]:checked').value
//     }
//     tableOfTaskS.push(TabTask);
//     localStorage.setItem('tableOfTaskS', JSON.stringify(tableOfTaskS));
//     affichage();
//     resetForm();
// })

// function affichage() {
//     todo.innerHTML = '';
//     inProgress.innerHTML = '';
//     todo.innerHTML = '';
//     var countTodo = 1;
//     var countProg = 1;
//     var countDone = 1;
//     for (let i = 0; i < tableOfTaskS.length; i++) {
//         if (tableOfTaskS[i].priority == 1) {
//             var priority = "Urgent";
//         } else if (tableOfTaskS[i].priority == 2) {
//             var priority = "Hight";
//         } else if (tableOfTaskS[i].priority == 3) {
//             var priority = "Medium";
//         } else {
//             var priority = "Low";
//         }
//         if (tableOfTaskS[i].type == 1) {
//             var type = "Feature";
//         } else {
//             var type = "Bug";
//         }
//         var descrLenght = tableOfTaskS[i].description.length;
//         if (descrLenght > 30) {
//             var description = tableOfTaskS[i].description.substr(0, 40);
//         } else {
//             description = tableOfTaskS[i].description;
//         }
//         if (tableOfTaskS[i].status == 1) {

//             todo.innerHTML += `
//                     <div >
//                     <button onclick="updateTask(this)" data-bs-toggle="modal" data-bs-target="#AddTask" class="d-flex button w-100 border p-1 " id="btn-1">
//                         <div class="col-md-1">
//                             <i class="bi bi-question-circle text-success"></i>

//                         </div>
//                         <div class="col-md-11 text-start">
//                             <div class=" fw-bold">${tableOfTaskS[i].titre}</div>
//                             <div class=" ">
//                                 <div class="text-black-50  "># <span>${i+1} </span> created in ${tableOfTaskS[i].date} </div>
//                                 <div class=" " title=${tableOfTaskS[i].description}>
//                       ${description}...</div>
//                             </div>
//                             <div class="d-flex justify-content-between align-items-center ">
//                                 <div>

//                                     <span class="col-md-auto btn btn-primary rounded-bottom rounded-top ">${priority} </span>
//                                     <span class=" col-md-auto btn btn-gray  ">${type} </span>
//                                 </div> 

//                             </div>


//                         </div>
//                     </button>
//                                         <div class="d-flex  justify-content-end">
//                                         <span class=" options">

//                                         <i  onclick="deleteTask(this)"  class=" fa fa-trash-alt btn btn-danger "></i> 
//                                         </span> 
//                                         </div>
//                     </div>

//                     `;


//             spanToDo.innerHTML = countTodo++;

//         } else if (tableOfTaskS[i].status == 2) {
//             inProgress.innerHTML += `
//             <div >
//             <button onclick="updateTask(this)" data-bs-toggle="modal" data-bs-target="#AddTask"  class="d-flex button w-100 border p-1 " id="btn-1">
//                 <div class="col-md-1">
//                     <i class="bi bi-question-circle text-success"></i>

//                 </div>
//                 <div class="col-md-11 text-start">
//                     <div class=" fw-bold">${tableOfTaskS[i].titre}</div>
//                     <div class=" ">
//                         <div class="text-black-50  "># <span>${i+1} </span> created in ${tableOfTaskS[i].date} </div>
//                         <div class=" " title=${tableOfTaskS[i].description}>
//               ${description}...</div>
//                     </div>
//                     <div class="d-flex justify-content-between align-items-center ">
//                         <div>

//                             <span class="col-md-auto btn btn-primary rounded-bottom rounded-top ">${priority} </span>
//                             <span class=" col-md-auto btn btn-gray  ">${type} </span>
//                         </div> 

//                     </div>


//                 </div>
//             </button>
//                                 <div class="d-flex  justify-content-end">
//                                 <span class=" options">

//                                 <i  onclick="deleteTask(this)"  class=" fa fa-trash-alt btn btn-danger "></i> 
//                                 </span> 
//                                 </div>
//             </div>

//             `;
//             spanInProgress.innerHTML = countProg++;

//         } else if (tableOfTaskS[i].status == 3) {
//             done.innerHTML += `
//             <div >
//             <button onclick="updateTask(this)" data-bs-toggle="modal" data-bs-target="#AddTask"  class="d-flex button w-100 border p-1 " id="btn-1">
//                 <div class="col-md-1">
//                     <i class="bi bi-question-circle text-success"></i>

//                 </div>
//                 <div class="col-md-11 text-start">
//                     <div class=" fw-bold">${tableOfTaskS[i].titre}</div>
//                     <div class=" ">
//                         <div class="text-black-50  "># <span>${i+1} </span> created in ${tableOfTaskS[i].date} </div>
//                         <div class=" " title=${tableOfTaskS[i].description}>
//               ${description}...</div>
//                     </div>
//                     <div class="d-flex justify-content-between align-items-center ">
//                         <div>

//                             <span class="col-md-auto btn btn-primary rounded-bottom rounded-top ">${priority} </span>
//                             <span class=" col-md-auto btn btn-gray  ">${type} </span>
//                         </div> 

//                     </div>


//                 </div>
//             </button>
//                                 <div class="d-flex  justify-content-end">
//                                 <span class=" options">

//                                 <i  onclick="deleteTask(this)"  class=" fa fa-trash-alt btn btn-danger "></i> 
//                                 </span> 
//                                 </div>
//             </div>

//             `;
//             spanDone.innerHTML = countDone++;

//         }
//     }
// }
// addTask.addEventListener("click", () => {
//     addTask.setAttribute("data-bs-dismiss", "modal");
// })

// function resetForm() {
//     form.titre.value = "",
//         description.value = "",
//         form.date.value = "",
//         form.priority.value = "",
//         form.status.value = " "

// }

// function deleteTask(trash) {
//     var getId = trash.parentElement.parentElement.parentElement;
//     var id = getId.children[0].children[1].children[1].children[0].children[0].innerHTML;
//     trash.parentElement.parentElement.parentElement.remove();
//     tableOfTaskS.splice(id - 1, 1);
//     tableOfTaskS = localStorage.setItem('tableOfTaskS', JSON.stringify(tableOfTaskS));


// }

// document.getElementById("btn-1").addEventListener("click", () => {

//     SaveTask.style.display = 'none';
//     document.getElementById("updateTask").style.display = 'block';
// })
// document.getElementById("addTaskBtn").addEventListener("click", () => {
//     document.getElementById("updateTask").style.display = 'none';
//     SaveTask.style.display = 'block';
// })


// function updateTask(update) {
//     var getId = update.children[1].children[1].children[0].children[0].innerHTML;

//     form.titre.value = tableOfTaskS[getId - 1].titre;

//     form.date.value = tableOfTaskS[getId - 1].date;

//     form.description.value = tableOfTaskS[getId - 1].description;
//     if (tableOfTaskS[getId - 1].type == 2) {
//         document.getElementById('radio2').checked = true;
//     } else {

//         document.getElementById('radio1').checked = true;
//     }
//     if (tableOfTaskS[getId - 1].priority == 1) {

//         document.getElementById('p1').selected = true;

//     } else if (tableOfTaskS[getId - 1].priority == 2) {

//         document.getElementById('p2').selected = true;

//     } else if (tableOfTaskS[getId - 1].priority == 3) {

//         document.getElementById('p3').selected = true;

//     } else {

//         document.getElementById('p4').selected = true;
//     }
//     if (tableOfTaskS[getId - 1].status == 1) {

//         document.getElementById('s1').selected = true;

//     } else if (tableOfTaskS[getId - 1].status == 2) {

//         document.getElementById('s2').selected = true;

//     } else {

//         document.getElementById('s3').selected = true;

//     }
//     document.getElementById("updateTask").addEventListener("click", (e) => {
//         var tabUpdate = {
//             titre: form.titre.value,
//             description: form.description.value,
//             date: form.date.value,
//             priority: form.priority.value,
//             status: form.status.value,
//             type: document.querySelector('input[name="radio"]:checked').value
//         }

//         tableOfTaskS.splice(getId - 1, 1, tabUpdate);
//         localStorage.setItem('tableOfTaskS', JSON.stringify(tableOfTaskS));


//     })

//     affichage();

// }