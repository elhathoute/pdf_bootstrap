
<?php 
 require_once("./assets/db/connectdb.php");
 $requetTodo =" SELECT * FROM tasks WHERE status=1" ;
 $todoTask= mysqli_query($connexion,$requetTodo);

 $requetInprogress =" SELECT * FROM tasks WHERE status=2" ;
 $inProgressTask= mysqli_query($connexion,$requetInprogress);

 $requetDone =" SELECT * FROM tasks WHERE status=3" ;
 $doneTask= mysqli_query($connexion,$requetDone);
 
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>YouCode | Scrum Board </title>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- ================== BEGIN core-css ================== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
    <link href="assets/css/vendor.min.css" rel="stylesheet" />
    <link href="assets/css/default/app.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet" />

    <!-- ================== END core-css ================== -->
</head>

<body>


    <!-- BEGIN #app -->
    <div id="app " class="app-without-sidebar ">

        <!-- BEGIN #content -->
        <div id="content " class="app-content main-style ">
            <div class="d-flex  justify-content-between align-items-center ">
                <div id="breadcrumb-h1" class="breadcrumb-h1 ">

                    <ol class="breadcrumb ">
                        <li class="breadcrumb-item "><a href="javascript:; ">Home</a></li>
                        <li class="breadcrumb-item active " aria-current="location ">Scrum Board </li>
                    </ol>
                    <!-- BEGIN page-header -->
                    <h1 class="page-header ">
                        Scrum Board
                    </h1>
                    <!-- END page-header -->
                </div>

                <div class="d-flex align-items-center ">
                    <button type="button" class="btn btn-info rounded-pill " data-bs-toggle="modal" data-bs-target="#AddTask" id="addTaskBtn"><i class="bi bi-plus  "></i>  Add Task</a>
						
    </div>
    </div>

    <div class="row " id="row">
        <div class="col-lg-4  col-md-6 col-sm-12 col-xs-12 " >
            <div class="card" id="card">
                <div class="card-header p-2 bg-dark rounded-top ">
                    <h4 class="text-white  ">To do (<span id="to-do-tasks-count"><?php echo 0; ?></span>)</h4>
                    </div>
               
                <div class="card-body  bg-info" id="TodoTask">
                    <!-- TO DO TASKS HERE -->
                   
							
                    <?php while($todo=mysqli_fetch_assoc($todoTask)) { 
                        ($todo['type']==1) ? $type='Feature' : $type ='Bug';
                       ($todo['priority']==1) ? ($priority='Urgent') : ($todo['priority']==2) ? ($priority ='Hight'): ($todo['priority']==3) ? ($priority ='Meduim' ): ($priority ='Low');
                         ?>
                    <button class="d-flex button w-100 border p-1 ">
								<div class=" col-md-1 ">
									<i class=" fa fa-question text-success"></i> 
								</div>
								<div class=" col-md-11 text-start">
									<div class=" fw-bold"><?php echo $todo['titre'] ?></div>
									<div class=" ">
										<div class=" text-black-50">#<?php echo $todo['id']. 'created in ' . $todo['date'] ?></div>
										<div class=" " title="The mockup provided can sometimes be confusing for developers. Especially if it contains much more content than the scope of the task described. Drop a couple of arrows, outlines and annotations here and there to emphasize
            what are the important parts of the mockup from the task requirements perspective. "><?php echo $todo['description'] ?></div>
									</div>
									<div class=" ">
										<span class=" col-md-auto btn btn-primary rounded-bottom rounded-top "><?php echo $priority ?></span>
										<span class="col-md-auto btn btn-gray "><?php echo $type ?></span>
									</div>
								</div>
							</button>
                            <?php }?>
                           
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
            <div class="card ">
                <div class="card-header p-2 bg-dark rounded-top ">
                    <h4 class=" text-white">In Progress (<span id="in-progress-tasks-count"><?php echo 0; ?></span>)</h4>

                    </div>
                <div class="card-body   bg-info" id="in-Progress ">
                    <!-- IN PROGRESS TASKS HERE -->
                    <?php while($inProgress=mysqli_fetch_assoc($inProgressTask)) { 
                        ($inProgress['type']==1) ? $type='Feature' : $type ='Bug';
                       ($inProgress['priority']==1) ? ($priority='Urgent') : ($inProgress['priority']==2) ? ($priority ='Hight'): ($inProgress['priority']==3) ? ($priority ='Meduim' ): ($priority ='Low');
                         ?>
                    <button class="d-flex button w-100 border p-1 ">
								<div class=" col-md-1 ">
                                <i class="fa fa-calendar text-success "></i> 
								</div>
								<div class=" col-md-11 text-start">
									<div class=" fw-bold"><?php echo $inProgress['titre'] ?></div>
									<div class=" ">
										<div class=" text-black-50">#<?php echo $inProgress['id']. 'created in ' . $inProgress['date'] ?></div>
										<div class=" " title="The mockup provided can sometimes be confusing for developers. Especially if it contains much more content than the scope of the task described. Drop a couple of arrows, outlines and annotations here and there to emphasize
            what are the important parts of the mockup from the task requirements perspective. "><?php echo $inProgress['description'] ?></div>
									</div>
									<div class=" ">
										<span class=" col-md-auto btn btn-primary rounded-bottom rounded-top "><?php echo $priority ?></span>
										<span class="col-md-auto btn btn-gray "><?php echo $type ?></span>
									</div>
								</div>
							</button>
                            <?php }?>
                           
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
       
        <div class="card">
                <div class=" card-header p-2 bg-dark rounded-top">
                    <h4 class="text-white ">Done (<span id="done-tasks-count"><?php echo 0; ?></span>)</h4>
                    </div>
                    <div class="card-body bg-info" id="done-task">
                    <?php while($done=mysqli_fetch_assoc($doneTask)) { 
                        ($done['type']==1) ? $type='Feature' : $type ='Bug';
                       ($done['priority']==1) ? ($priority='Urgent') : ($done['priority']==2) ? ($priority ='Hight'): ($done['priority']==3) ? ($priority ='Meduim' ): ($priority ='Low');
                         ?>
                    <button class="d-flex button w-100 border p-1 ">
								<div class=" col-md-1 ">
                                <i class="fa fa-check text-success "></i> 
								</div>
								<div class=" col-md-11 text-start">
									<div class=" fw-bold"><?php echo $done['titre'] ?></div>
									<div class=" ">
										<div class=" text-black-50">#<?php echo $done['id']. 'created in ' . $done['date'] ?></div>
										<div class=" " title="The mockup provided can sometimes be confusing for developers. Especially if it contains much more content than the scope of the task described. Drop a couple of arrows, outlines and annotations here and there to emphasize
            what are the important parts of the mockup from the task requirements perspective. "><?php echo $done['description'] ?></div>
									</div>
									<div class=" ">
										<span class=" col-md-auto btn btn-primary rounded-bottom rounded-top "><?php echo $priority ?></span>
										<span class="col-md-auto btn btn-gray "><?php echo $type ?></span>
									</div>
								</div>
							</button>
                            <?php }?>
            
                
                    <!-- DONE TASKS HERE -->

                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- END #content -->


    <!-- BEGIN scroll-top-btn -->
    <a href="javascript:; " class="btn btn-icon btn-circle btn-success btn-scroll-to-top " data-toggle="scroll-to-top "><i class="fa fa-angle-up "></i></a>
    <!-- END scroll-top-btn -->
    </div>
    <!-- END #app -->

    <!-- TASK MODAL -->

    <!-- Modal content goes here -->
  


    <!-- ================== BEGIN core-js ================== -->
    <script src="assets/js/vendor.min.js "></script>
    <script src="assets/js/app.min.js "></script>
    <!-- <script src="assets/js/main.js"></script> -->
    <!-- ================== END core-js ================== -->
</body>


</html>